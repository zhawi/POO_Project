package ual.poo.TransportationCompany;

enum Permission {
    N,
    S,
    P
}
