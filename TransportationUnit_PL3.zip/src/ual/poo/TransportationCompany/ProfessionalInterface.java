package ual.poo.TransportationCompany;

public interface ProfessionalInterface {
}
