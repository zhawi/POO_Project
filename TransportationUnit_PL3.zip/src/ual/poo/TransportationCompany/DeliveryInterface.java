package ual.poo.TransportationCompany;

public interface DeliveryInterface {
     void addDeliveryId (int deliveryId);
}
