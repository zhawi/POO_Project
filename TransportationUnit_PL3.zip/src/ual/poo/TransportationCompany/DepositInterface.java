package ual.poo.TransportationCompany;

public interface DepositInterface {
     void addDepositId(int depositId);
}
