package ual.poo.TransportationCompany;

public interface LocalInterface {
}
