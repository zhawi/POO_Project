package ual.poo.TransportationCompany;

public enum Categories {
    CONDUTOR,
    CARREGADOR,
    GESTOR
}
