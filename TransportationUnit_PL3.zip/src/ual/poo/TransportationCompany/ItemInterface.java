package ual.poo.TransportationCompany;

public interface ItemInterface {
}
